from abstract_utilities import read_directory
input(read_directory('/home/computron/Documents/pythonTools/modules/abstract_utilities'))
