# file_reader.py

import os,fnmatch
from pathlib import Path
from typing import Set, List
from abstract_utilities import make_list,get_media_exts, is_media_type  # assuming you have these

# ─── Configuration ────────────────────────────────────────────────────────────

# What you *do* want to include by extension:
DEFAULT_ALLOWED_EXTS: Set[str] = {
    # Python
    ".py", ".pyw",
    # JS / TS
    ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs",
    # Markup
    ".html", ".htm", ".xml",
    # Styles
    ".css", ".scss", ".sass", ".less",
    # Data / config
    ".json", ".yaml", ".yml", ".toml", ".ini", ".cfg",
    # Docs
    ".md", ".markdown", ".rst",
    # Shell
    ".sh", ".bash",
    # Environment
    ".env",
    # Plain text
    ".txt",
}
DEFAULT_EXLUDED_TYPES: Set[str] = {"image", "video", "audio", "presentation","spreadsheet","archive","executable"}
# What you *never* want, regardless
unallowed_exts: Set[str] = set(
    get_media_exts(DEFAULT_EXLUDED_TYPES)
) | {".pyc"}

DEFAULT_UNALLOWED_EXTS: Set[str] = [unallowed_ext for unallowed_ext in list(unallowed_exts) if unallowed_ext not in list(DEFAULT_ALLOWED_EXTS)]
# Directory names to skip entirely
DEFAULT_EXCLUDE_DIRS: Set[str] = {
    "node_modules",
    "__pycache__",
    "backups",
    "backup",
}

# Filename patterns to skip (uses fnmatch)
DEFAULT_EXCLUDE_PATTERNS: List[str] = [
    "__init__*",  # e.g. __init__.py or __init__.backup
    "*.tmp",
    "*.log",
    "*.lock",     # if you decide later you want lockfiles back you can remove this
    "*.zip",      # archives
]


# ─── Core predicate ───────────────────────────────────────────────────────────

def is_allowed(path: str) -> bool:
    """
    Return True if `path` should be included in our drop/concat step.
    Excludes:
      • Directories in DEFAULT_EXCLUDE_DIRS
      • Files matching DEFAULT_EXCLUDE_PATTERNS
      • Files whose extension is in DEFAULT_UNALLOWED_EXTS
      • Files whose media-type category is in DEFAULT_EXCLUDE_TYPES
      • Files *not* in DEFAULT_ALLOWED_EXTS
    """
    p = Path(path)
    name = p.name.lower()

    # 1) Skip dirs outright
    if p.is_dir() and name in DEFAULT_EXCLUDE_DIRS:
        return False

    # 2) Skip by glob-pattern
    for pat in DEFAULT_EXCLUDE_PATTERNS:
        if fnmatch.fnmatch(name, pat.lower()):
            return False

    # 3) Skip by media-type category (images, video, audio, presentation)
    #    Assumes your is_media_type(filename, media_types=...) helper
    if is_media_type(path, media_types=DEFAULT_EXCLUDE_TYPES):
        return False

    # 4) Extension checks
    ext = p.suffix.lower()
    if ext in DEFAULT_UNALLOWED_EXTS:
        return False
    if ext not in DEFAULT_ALLOWED_EXTS:
        return False

    # Passed all filters → keep it
    return True

# ─── Example walker ──────────────────────────────────────────────────────────

def collect_files(
    root_dir: str,
    *,
    allowed: callable = is_allowed
) -> List[str]:
    """
    Walk `root_dir` recursively, returning a flat list of all files
    for which `allowed(path) is True`.
    """
    out = []
    for dirpath, dirnames, filenames in os.walk(root_dir):
        # mutate dirnames in-place to skip unwanted dirs
        dirnames[:] = [d for d in dirnames if d not in DEFAULT_EXCLUDE_DIRS]
        for fn in filenames:
            full = os.path.join(dirpath, fn)
            if allowed(full):
                out.append(full)
    return out

def read_directory(
    root_path: str,
) -> Dict[str, Union[pd.DataFrame, str]]:
    """
    Walk `root_path`, collect only files for which `is_allowed(path)` returns True.
    Returns a dict mapping relative path → either:
      • str (raw text)
      • pd.DataFrame or gpd.GeoDataFrame
      • for multi-sheet files, entries under "relpath::[sheetname]"
    """
    if not os.path.isdir(root_path):
        raise FileNotFoundError(f"Not a valid directory: {root_path!r}")

    root_path = os.path.abspath(root_path)
    root_prefix_len = len(root_path.rstrip(os.sep)) + 1

    collected: Dict[str, Union[pd.DataFrame, str]] = {}

    for full_path in collect_files(root_path):
        rel_path = full_path[root_prefix_len:]
        ext = Path(full_path).suffix.lower()

        # ——— 1) Pure-text quick reads —————————————
        if ext in {'.txt', '.md', '.csv', '.tsv', '.log'}:
            try:
                with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                    collected[rel_path] = f.read()
                _logger.info(f"Read text file: {rel_path}")
            except Exception as e:
                _logger.warning(f"Failed to read {rel_path} as text: {e}")
            continue

        # ——— 2) Try your DataFrame loader ——————————
        try:
            df_or_map = get_df(full_path)
            if isinstance(df_or_map, (pd.DataFrame, gpd.GeoDataFrame)):
                collected[rel_path] = df_or_map
                _logger.info(f"Loaded DataFrame: {rel_path}")
                continue

            if isinstance(df_or_map, dict):
                for sheet, df in df_or_map.items():
                    key = f"{rel_path}::[{sheet}]"
                    collected[key] = df
                    _logger.info(f"Loaded sheet DataFrame: {key}")
                continue
        except Exception as e:
            _logger.debug(f"get_df failed for {rel_path}: {e}")

        # ——— 3) Fallback to generic text extractor ————
        try:
            parts = read_file_as_text(full_path)  # List[str]
            combined = "\n\n".join(parts)
            collected[rel_path] = combined
            _logger.info(f"Read fallback text for: {rel_path}")
        except Exception as e:
            _logger.warning(f"Could not read {rel_path} at all: {e}")

    return collected
